utils::globalVariables(c("age","time","geo","sex","values", "User_code", "Year",
                         "Age","Value","qv","qt",
                         "year", "var", "trend_name", "x", "y",
                         "sim", "model", "median", "trend", "quantile",
                         "tmax", "tmin", "tmedian"))
